/*
 * CFile1.c
 *
 * Created: 2018-04-19 20:43:30
 *  Author: Lemur
 */ 

#include <avr/io.h>
#include "serial_io.h"

/**
 * @brief Configure the USART0 port.
 */
void serial_init(comm_struct* cs) {
	// remap TX to pin3
	cs->port->OUTSET = cs->eight;
	cs->port->DIRSET = cs->eight;

	// remap RX to pin2
	cs->port->OUTCLR = cs->four;
	cs->port->DIRCLR = cs->four;

	// WTF?
	cs->usart->CTRLA = cs->usart->CTRLA;
	cs->usart->CTRLA = cs->usart->CTRLA;
	cs->usart->CTRLA = cs->usart->CTRLA;

	//Enable receive and transmit
	cs->usart->CTRLB = USART_CLK2X_bm; // double tx speed

	//8 data bits, no parity and 1 stop bit
	cs->usart->CTRLC = USART_CHSIZE_8BIT_gc; // 8N1

	// set baud 115200
	cs->usart->BAUDCTRLB = 0; // BScale = 0
	cs->usart->BAUDCTRLA = 0x23; // BSEL = 34 -> 115200, for some clock rate...
	cs->usart->CTRLB |= USART_RXEN_bm | USART_TXEN_bm;
	
}

/**
 * @brief Send a single byte.
 * @param[in] usart  Port to send on
 * @param[in] byte  Byte to send
 */
void usart_send_byte(USART_t* usart, uint8_t byte) {
	while ( (usart->STATUS & USART_DREIF_bm) == 0) {
		// wait until ready	
	}
	/* Send byte */
	usart->DATA = byte;
}

/**
 * @brief Get incoming data.
 * @return Received byte.
 */
uint8_t usart_recv_byte(USART_t* usart) {
	/* Wait until data is available */
	while ( (usart->STATUS & USART_RXCIF_bm) == 0) {
		// wait until ready
	}

	/* Read byte */
	uint8_t byte = usart->DATA;
	
	usart_send_byte(usart, byte);
	return byte;
}
 