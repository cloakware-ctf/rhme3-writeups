/* RHme3
 * Side Channel Analysis - The Impostors
 *
 * might be better to use otsc:
 * https://github.com/eewiki/asf/blob/master/xmega/drivers/aes/aes.h
 * https://github.com/eewiki/asf/blob/master/xmega/drivers/aes/aes.c
 */

#include <stdint.h>
#include <stdlib.h>
#include <avr/pgmspace.h>

#include "serial_io.h"

#define AES_KEY_SIZE 16
#define AES_STATE_SIZE 16

static const uint8_t key[AES_KEY_SIZE] = {0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c};
static const uint8_t lastroundkey[AES_KEY_SIZE] = {0xd0, 0x14, 0xf9, 0xa8, 0xc9, 0xee, 0x25, 0x89, 0xe1, 0x3f, 0x0c, 0xc8, 0xb6, 0x63, 0x0c, 0xa6};
static uint8_t buf[AES_STATE_SIZE];
static uint8_t decoy[AES_STATE_SIZE];


void fill_buf(USART_t *usart) {
    for (uint8_t i = 0; i < AES_STATE_SIZE; i++) {
        buf[i] = usart_recv_byte(usart);
    }
}

void send_buf(USART_t *usart) {
    for (uint8_t i = 0; i < AES_STATE_SIZE; i++) {
        usart_send_byte(usart, buf[i]);
    }
}

uint8_t read_newline(USART_t *usart) {
	 return usart_recv_byte(usart) == '\n';
}

void encrypt() {
	uint8_t i;
	AES.CTRL = AES_AUTO_bm; // encrypt is default
    for (i = 0; i < AES_KEY_SIZE; i++) {
		AES.KEY = key[i];
	}
    for (i = 0; i < AES_STATE_SIZE; i++) {
	    AES.STATE = buf[i];
    }
	// AES.CTRL = AES_START_bm; // don't need to, auto start set
	while ( (AES.STATUS & (AES_SRIF_bm | AES_ERROR_bm)) == 0) {
		// waiting...
	}
    for (i = 0; i < AES_STATE_SIZE; i++) {
		buf[i] = AES.STATE;
    }
}

void decrypt() {
	uint8_t i;
	AES.CTRL = AES_DECRYPT_bm | AES_AUTO_bm;
	for (i = 0; i < AES_KEY_SIZE; i++) {
		//AES.KEY = lastroundkey[i];
	}
	for (i = 0; i < AES_STATE_SIZE; i++) {
		AES.STATE = buf[i];
	}
	// AES.CTRL = AES_START_bm; // don't need to, auto start set
	while ( (AES.STATUS & (AES_SRIF_bm | AES_ERROR_bm)) == 0) {
		// waiting...
	}
	for (i = 0; i < AES_STATE_SIZE; i++) {
		buf[i] = AES.STATE;
	}
}

void setup_clock() {
	// enable 32MHz clock, and wait for it to be ready
	OSC_CTRL |= OSC_RC32MEN_bm;
	while ( (OSC_STATUS & OSC_RC32MRDY_bm) == 0 ) {
		/**/
	}
	
	// setup system to use it
	CPU_CCP = CCP_IOREG_gc;
	CLK_CTRL = CLK_SCLKSEL_RC32M_gc | CLK_PSADIV_1_gc;
	
	// why we do this?
	OSC_CTRL &= ~OSC_RC2MEN_bm;
}

void randomness(void) {
	long r;
	srand(buf[0] << 8 | buf[1]);
	for(uint8_t i=0; i<AES_STATE_SIZE*5/2; i++) {
		r = random();
		decoy[(i+0)%sizeof(decoy)] ^= (r >> 24) & 0xff;
		decoy[(i+1)%sizeof(decoy)] ^= (r >> 16) & 0xff;
		decoy[(i+2)%sizeof(decoy)] ^= (r >>  8) & 0xff;
		decoy[(i+3)%sizeof(decoy)] ^= (r >>  0) & 0xff;
	}
}

comm_struct p_USARTC0 = {
	(&USARTC0),
	(&PORTC),
	PIN2_bm,
	PIN3_bm
};
comm_struct *pp_USARTC0 = &p_USARTC0;


int main(void) {
	uint8_t command;

	setup_clock();
	serial_init(pp_USARTC0);
	
	while (0) {
		usart_send_byte(&USARTC0, 0x00);
		usart_send_byte(&USARTC0, 0x55);
		usart_send_byte(&USARTC0, 0xaa);
		usart_send_byte(&USARTC0, 0x55);
		usart_send_byte(&USARTC0, 0x00);
	}
	

	while (1) {
		command = usart_recv_byte(p_USARTC0.usart);
		switch (command) {
			case 0xAE:
				fill_buf(p_USARTC0.usart);
				if (read_newline(p_USARTC0.usart)) {
					randomness();
					encrypt();
					randomness();
				}
				send_buf(p_USARTC0.usart);
				break;

			case 0xAD:
				fill_buf(p_USARTC0.usart);
				if (read_newline(p_USARTC0.usart)) {
					randomness();
					decrypt();
					randomness();
				}
				send_buf(p_USARTC0.usart);
				break;
			
			default:
				break;
		}
	}

	return 0;
}