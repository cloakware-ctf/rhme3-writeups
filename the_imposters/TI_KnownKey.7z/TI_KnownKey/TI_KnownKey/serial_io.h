/*
 * IncFile1.h
 *
 * Created: 2018-04-19 20:44:25
 *  Author: Lemur
 */ 

#include <stdint.h>

#ifndef SERIAL_IO_H
#define SERIAL_IO_H

typedef struct {
	USART_t *usart;
	PORT_t *port;
	uint8_t four;
	uint8_t eight;
} comm_struct;

void serial_init(comm_struct* cs);

void usart_send_byte(USART_t* usart, uint8_t byte);

uint8_t usart_recv_byte(USART_t* usart);

#endif /* SERIAL_IO_H */